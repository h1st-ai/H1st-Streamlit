import os
PROJECT_DIR = os.path.dirname(__file__)

# Update your data path here
DATA_PATH = f"{PROJECT_DIR}/data"
MODEL_REPO_PATH = "s3://h1st-model-repo/digit_classifier"
