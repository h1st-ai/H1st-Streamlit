Recognize user provided hand-written numbers.  
Base_model is trained with MNIST dataset.   
<br/>
To run backend and frontend, run the following commands  
* backend: uvicorn api.main:app --reload  
* frontend: yarn start  
